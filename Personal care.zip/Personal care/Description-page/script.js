//slider part
var mi=document.getElementById("mainImage");
var thumbnail=document.getElementsByClassName("sliderr");
var left=document.querySelector(".arrow");
var right=document.querySelector(".right");
var currentIndex=0;
for(let i=0;i<thumbnail.length;i++)
    {
        thumbnail[i].addEventListener('click',function()
        {
            mi.src=thumbnail[i].src;
            currentIndex=i;
        });
    }
    left.addEventListener('click',function()
    {
        
        currentIndex=(currentIndex-1+thumbnail.length)%thumbnail.length
        mi.src=thumbnail[currentIndex].src;
        
    })

  right.addEventListener('click',function()
{
    currentIndex=(currentIndex+1)%thumbnail.length
    mi.src=thumbnail[currentIndex].src;

})
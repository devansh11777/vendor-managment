<script>
  const removeBtn = document.querySelector('.remove');
  const addMoreBtn = document.querySelector('.add');
  const cartSection = document.querySelector('.cart-section');
  const cartItem = document.querySelector('.cart-item');
  const payoutSection = document.querySelector('.payout-section');
  const checkbox = document.querySelector('.checkbox');

  removeBtn.addEventListener('click', () => {
    if (checkbox.checked) {
      cartItem.remove();
      cartSection.innerHTML += `<p style="font-size: 18px; color: grey;">Cart is empty</p>`;
      payoutSection.innerHTML = `<h2>Total payout</h2><p style="color: grey;">No items to display.</p>`;
    }
  });

  addMoreBtn.addEventListener('click', () => {
    // You can replace this with your actual homepage link
    window.location.href = ""; 
  });
</script>
